EXPECTED_PATHS = {
    "/api/v1/health",
    "/api/v1/health/ready",
    "/api/v1/auth/status",
    "/api/v1/auth/login",
    "/api/v1/screenings",
    "/api/v1/screenings/{screening_id}",
    "/api/v1/screenings/{screening_id}/report",
    "/api/v1/history",
    "/api/v1/llm/generate",
}


def test_openapi_exposes_contracted_paths(client):
    paths = set(client.get("/openapi.json").json()["paths"])
    assert EXPECTED_PATHS <= paths


def test_no_frontend_or_cors_coupling(client):
    # CORS is intentionally absent until the frontend phase.
    r = client.options("/api/v1/health", headers={
        "Origin": "https://example.invalid",
        "Access-Control-Request-Method": "GET",
    })
    assert "access-control-allow-origin" not in {k.lower() for k in r.headers}


def test_screening_schema_documents_region_and_image(client):
    spec = client.get("/openapi.json").json()
    body_schema = spec["paths"]["/api/v1/screenings"]["post"]["requestBody"]["content"]
    assert "multipart/form-data" in body_schema
    props = body_schema["multipart/form-data"]["schema"]
    ref = props.get("$ref", "")
    name = ref.rsplit("/", 1)[-1]
    fields = spec["components"]["schemas"][name]["properties"]
    assert {"region", "image"} <= set(fields)
