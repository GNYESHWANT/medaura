import pyarrow as pa
import pytest

from app.rag.ingest import ensure_empty_tables
from app.rag.parquet import TABLES, read_table, schema_for, validate_rows, write_table
from app.rag.retrieve import EvidenceItem, NullVectorStore, Retriever, build_default_retriever
from app.rag.rerank import PassthroughReranker
from app.rag.embed import EmbeddingProvider

EXPECTED_TABLES = {
    "conditions", "causes", "prevention", "care", "risk_factors",
    "specialists", "symptoms", "red_flags", "guidelines", "sources",
}


def test_all_required_tables_defined():
    assert set(TABLES) == EXPECTED_TABLES


@pytest.mark.parametrize("table", sorted(EXPECTED_TABLES))
def test_provenance_fields_present(table):
    names = set(schema_for(table).names)
    if table == "sources":
        assert {"source_id", "source_title", "source_type", "publication_date", "organization", "url_or_doi"} <= names
    else:
        assert {"body_region", "description", "evidence_level", "source_id", "source_title",
                "source_type", "publication_date", "organization", "url_or_doi", "text"} <= names


def test_conditions_schema_has_key_fields():
    assert {"condition_id", "condition_name", "body_region"} <= set(schema_for("conditions").names)


def test_ensure_empty_tables_writes_all_schemas(tmp_path):
    written = ensure_empty_tables(tmp_path)
    assert len(written) == len(EXPECTED_TABLES)
    for table in EXPECTED_TABLES:
        t = read_table(table, tmp_path / "parquet")
        assert t.num_rows == 0
        assert t.schema.names == schema_for(table).names


def test_write_and_read_round_trip(tmp_path):
    row = {
        "source_id": "src-1", "source_title": "Example guideline", "source_type": "guideline",
        "publication_date": "2025-01-01", "organization": "Example Org", "url_or_doi": "doi:10.0/x",
        "evidence_level": "B",
    }
    write_table("sources", [row], tmp_path)
    t = read_table("sources", tmp_path)
    assert t.num_rows == 1
    assert t.column("source_id").to_pylist() == ["src-1"]


def test_unknown_field_rejected():
    with pytest.raises(ValueError, match="unknown fields"):
        validate_rows("conditions", [{"condition_id": "c1", "made_up": "x"}])


def test_missing_id_rejected():
    with pytest.raises(ValueError, match="required"):
        validate_rows("conditions", [{"condition_name": "x"}])


def test_unsupported_body_region_rejected():
    with pytest.raises(ValueError, match="not supported"):
        validate_rows("conditions", [{"condition_id": "c1", "body_region": "liver"}])


def test_default_retriever_returns_not_configured_status():
    result = build_default_retriever().retrieve("eye query", "eye")
    assert result.status == "EMBEDDER_NOT_CONFIGURED"
    assert result.items == []


class _FakeEmbedder(EmbeddingProvider):
    def embed_texts(self, texts):
        return [[0.1, 0.2] for _ in texts]


class _FakeStore(NullVectorStore):
    def search(self, vector, body_region, top_k):
        return [EvidenceItem(source_id="s1", source_title="T", text="t", score=0.9)]


def test_retriever_contract_with_stub_backends():
    result = Retriever(_FakeEmbedder(), _FakeStore(), PassthroughReranker()).retrieve("q", "skin")
    assert result.status == "OK"
    assert result.items[0].source_id == "s1"
