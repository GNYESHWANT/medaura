import pytest

from app.core.config import get_settings
from app.models.base import MODEL_NOT_CONFIGURED, ModelPrediction
from app.risk import triage
from app.risk.severity import SeverityThresholds, severity_level

T = SeverityThresholds(blue=0.25, amber=0.5, red=0.8)


@pytest.mark.parametrize(
    "score, expected",
    [(0.0, "GREEN"), (0.24, "GREEN"), (0.25, "BLUE"), (0.5, "AMBER"), (0.79, "AMBER"), (0.8, "RED"), (1.0, "RED")],
)
def test_severity_banding(score, expected):
    assert severity_level(score, T) == expected


def test_severity_rejects_out_of_range():
    with pytest.raises(ValueError):
        severity_level(1.5, T)


def test_thresholds_must_be_ordered():
    with pytest.raises(ValueError):
        SeverityThresholds(blue=0.6, amber=0.5, red=0.8)


def _ok(score=None, confidence=None):
    return ModelPrediction(status="OK", region="skin", label="x", severity_hint=score, model_confidence=confidence)


def test_no_model_output_means_no_risk_level():
    r = triage.assess(quality_passed=True, prediction=ModelPrediction(status=MODEL_NOT_CONFIGURED, region="skin"),
                      red_flags=[], evidence_count=0)
    assert r.risk_level is None
    assert r.screening_status == "MODEL_NOT_CONFIGURED"
    assert "MODEL_NOT_CONFIGURED" in r.reason_codes


def test_quality_failure_requires_retake():
    r = triage.assess(quality_passed=False, prediction=None, red_flags=[], evidence_count=0)
    assert r.screening_status == "RETAKE_REQUIRED"
    assert r.risk_level is None
    assert r.urgency == "retake_image"


def test_red_flag_forces_red_even_without_image_result():
    r = triage.assess(quality_passed=True, prediction=None, red_flags=["sudden_vision_loss"], evidence_count=0)
    assert r.risk_level == "RED"
    assert "RED_FLAG:sudden_vision_loss" in r.reason_codes


def test_level_comes_from_severity_hint():
    r = triage.assess(quality_passed=True, prediction=_ok(score=0.6), red_flags=[], evidence_count=3)
    assert r.risk_level == "AMBER"
    assert r.screening_status == "COMPLETED"


def test_high_confidence_does_not_imply_high_severity():
    low_sev = triage.assess(quality_passed=True, prediction=_ok(score=0.1, confidence=0.99),
                            red_flags=[], evidence_count=3)
    assert low_sev.risk_level == "GREEN"


def test_low_confidence_is_flagged_but_does_not_change_level():
    r = triage.assess(quality_passed=True, prediction=_ok(score=0.1, confidence=0.2),
                      red_flags=[], evidence_count=3)
    assert r.risk_level == "GREEN"
    assert "LOW_MODEL_CONFIDENCE" in r.reason_codes


def test_missing_evidence_is_reported():
    r = triage.assess(quality_passed=True, prediction=_ok(score=0.1), red_flags=[], evidence_count=0)
    assert "NO_RETRIEVED_EVIDENCE" in r.reason_codes


def test_thresholds_are_read_from_settings():
    settings = get_settings()
    assert SeverityThresholds.from_settings(settings) == SeverityThresholds(
        settings.risk_blue_threshold, settings.risk_amber_threshold, settings.risk_red_threshold
    )
