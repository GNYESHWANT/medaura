def test_health_ok(client):
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert "version" in body


def test_health_ready_checks_database(client):
    r = client.get("/api/v1/health/ready")
    assert r.status_code == 200
    assert r.json()["database"] == "ok"


def test_auth_status_anonymous_when_disabled(client):
    r = client.get("/api/v1/auth/status")
    assert r.status_code == 200
    assert r.json() == {"auth_enabled": False, "mode": "anonymous", "actor": "anonymous"}


def test_auth_login_is_explicitly_not_implemented(client):
    r = client.post("/api/v1/auth/login")
    assert r.status_code == 501
    assert r.json()["code"] == "AUTH_NOT_IMPLEMENTED"
