import pytest

from app.core.config import get_settings

URL = "/api/v1/screenings"


def _png(data: bytes):
    return {"image": ("scan.png", data, "image/png")}


def test_unsupported_region_rejected(client, textured_png):
    r = client.post(URL, data={"region": "liver"}, files=_png(textured_png))
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "UNSUPPORTED_REGION"


def test_missing_image_rejected(client):
    r = client.post(URL, data={"region": "eye"})
    assert r.status_code == 422


def test_unsupported_media_type_rejected(client):
    r = client.post(URL, data={"region": "eye"}, files={"image": ("notes.txt", b"hello", "text/plain")})
    assert r.status_code == 415
    assert r.json()["detail"]["code"] == "UNSUPPORTED_MEDIA_TYPE"


def test_declared_png_with_non_image_bytes_rejected(client):
    r = client.post(URL, data={"region": "eye"}, files={"image": ("fake.png", b"not really a png", "image/png")})
    assert r.status_code == 415
    assert r.json()["detail"]["code"] == "INVALID_IMAGE"


def test_content_type_mismatch_rejected(client, textured_png):
    # PNG bytes declared as JPEG
    r = client.post(URL, data={"region": "eye"}, files={"image": ("x.jpg", textured_png, "image/jpeg")})
    assert r.status_code == 415
    assert r.json()["detail"]["code"] == "CONTENT_TYPE_MISMATCH"


def test_empty_file_rejected(client):
    r = client.post(URL, data={"region": "eye"}, files={"image": ("e.png", b"", "image/png")})
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "EMPTY_FILE"


def test_oversized_file_rejected(client, textured_png):
    limit = get_settings().max_upload_bytes
    big = textured_png + b"\0" * (limit + 1 - len(textured_png))
    r = client.post(URL, data={"region": "eye"}, files={"image": ("big.png", big, "image/png")})
    assert r.status_code == 413
    assert r.json()["detail"]["code"] == "FILE_TOO_LARGE"


def test_valid_screening_end_to_end_without_models(client, textured_png):
    r = client.post(URL, data={"region": "eye"}, files=_png(textured_png))
    assert r.status_code == 201
    created = r.json()
    assert created["status"] == "completed"
    screening_id = created["screening_id"]

    result = client.get(f"/api/v1/screenings/{screening_id}").json()
    assert result["body_region"] == "eye"
    assert result["image_quality"]["passed"] is True
    # No trained weights: the model must say so, never fabricate a prediction.
    assert result["prediction"]["status"] == "MODEL_NOT_CONFIGURED"
    assert result["prediction"]["label"] is None
    # Without a prediction there is no risk level.
    assert result["risk"]["risk_level"] is None
    assert result["risk"]["screening_status"] == "MODEL_NOT_CONFIGURED"
    assert result["specialist"]["specialty"] == "Ophthalmology"
    assert result["report"]["disclaimer"]


def test_low_quality_image_requires_retake(client, flat_png):
    r = client.post(URL, data={"region": "skin"}, files=_png(flat_png))
    assert r.status_code == 201
    result = client.get(f"/api/v1/screenings/{r.json()['screening_id']}").json()
    assert result["image_quality"]["passed"] is False
    assert result["risk"]["screening_status"] == "RETAKE_REQUIRED"
    assert result["risk"]["risk_level"] is None
    assert result["prediction"]["status"] == "SKIPPED"


def test_symptoms_red_flag_forces_red(client, textured_png):
    r = client.post(
        URL,
        data={"region": "eye", "symptoms": "sudden_vision_loss, not_a_real_code"},
        files=_png(textured_png),
    )
    result = client.get(f"/api/v1/screenings/{r.json()['screening_id']}").json()
    assert result["risk"]["risk_level"] == "RED"
    assert "RED_FLAG:sudden_vision_loss" in result["risk"]["reason_codes"]


def test_unknown_screening_returns_404(client):
    r = client.get("/api/v1/screenings/does-not-exist")
    assert r.status_code == 404


def test_report_endpoint_returns_structured_json(client, textured_png):
    created = client.post(URL, data={"region": "mouth"}, files=_png(textured_png)).json()
    r = client.get(f"/api/v1/screenings/{created['screening_id']}/report")
    assert r.status_code == 200
    body = r.json()
    assert body["body_region"] == "mouth"
    assert body["generated_by"].startswith("report_service")
    assert "not a diagnosis" in body["disclaimer"]


def test_history_lists_recent_screenings(client, textured_png):
    client.post(URL, data={"region": "nails"}, files=_png(textured_png))
    r = client.get("/api/v1/history?limit=5")
    assert r.status_code == 200
    assert len(r.json()["items"]) >= 1


def test_history_rejects_bad_limit(client):
    assert client.get("/api/v1/history?limit=0").status_code == 422
