import pytest

from app.llm.adapter import LLMAdapter, get_llm_adapter
from app.llm.interface import LLMNotImplementedError, LLMProvider
from app.llm.schemas import LLMRequest, LLMResponse
from app.main import app

URL = "/api/v1/llm/generate"
VALID_BODY = {
    "system_instruction": "Be brief.",
    "context": [{"source_id": "s1", "text": "Some cited text"}],
    "user_input": "What does this mean?",
    "structured_data": {},
}


def test_generate_returns_501_when_not_implemented(client):
    r = client.post(URL, json=VALID_BODY)
    assert r.status_code == 501
    assert r.json()["error"] == "NOT_IMPLEMENTED"


def test_generate_validates_request_before_501(client):
    r = client.post(URL, json={"user_input": ""})
    assert r.status_code == 422


def test_default_adapter_has_no_provider():
    adapter = get_llm_adapter()
    assert adapter.is_configured is False
    with pytest.raises(LLMNotImplementedError):
        adapter.generate(LLMRequest(system_instruction="s", user_input="u"))


class _MockProvider(LLMProvider):
    name = "mock-test-only"

    def generate(self, request: LLMRequest) -> LLMResponse:
        return LLMResponse(text="mock", citations=[], model="mock", usage={})


def test_mock_provider_via_dependency_override(client):
    # Test-only: proves the adapter contract. Never wired into production code.
    app.dependency_overrides[get_llm_adapter] = lambda: LLMAdapter(_MockProvider())
    try:
        r = client.post(URL, json=VALID_BODY)
        assert r.status_code == 200
        assert r.json()["text"] == "mock"
    finally:
        app.dependency_overrides.pop(get_llm_adapter, None)


def test_context_limits_enforced(client):
    body = dict(VALID_BODY, context=[{"text": "x" * 4001}])
    assert client.post(URL, json=body).status_code == 422
