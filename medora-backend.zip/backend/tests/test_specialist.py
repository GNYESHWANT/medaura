import pytest

from app.risk.red_flags import RedFlagRegistry
from app.risk.specialist import SpecialistRouter
from app.vision.router import UnsupportedRegion, build_region_models, normalize_region


@pytest.fixture(scope="module")
def router():
    return SpecialistRouter()


@pytest.mark.parametrize(
    "region, specialty",
    [("eye", "Ophthalmology"), ("skin", "Dermatology"), ("nails", "Dermatology"), ("mouth", "Dentistry")],
)
def test_region_defaults(router, region, specialty):
    rec = router.route(region)
    assert rec.specialty == specialty
    assert rec.source == "region_default"


def test_finding_override_takes_precedence(router):
    rec = router.route("mouth", "non_healing_ulcer")
    assert rec.specialty == "Oral medicine"
    assert rec.source == "finding_override"


def test_unknown_finding_falls_back_to_region_default(router):
    rec = router.route("mouth", "made_up_finding")
    assert rec.source == "region_default"


def test_mapping_version_is_recorded(router):
    assert router.route("eye").mapping_version == router.version


def test_region_normalisation():
    assert normalize_region(" EYE ") == "eye"
    with pytest.raises(UnsupportedRegion):
        normalize_region("knee")


def test_region_models_cover_all_regions():
    assert set(build_region_models()) == {"eye", "skin", "nails", "mouth"}


def test_red_flag_registry_ignores_unknown_codes():
    reg = RedFlagRegistry()
    assert reg.check("eye", {"sudden_vision_loss", "bogus"}) == ["sudden_vision_loss"]
    # A code valid for one region is not valid for another
    assert reg.check("skin", {"sudden_vision_loss"}) == []
