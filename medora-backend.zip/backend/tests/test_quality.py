import numpy as np
import pytest

from app.vision.preprocessing import crop_roi, decode_image
from app.vision.quality import ImageQualityService, QUALITY_DISCLAIMER


def _noise(h=512, w=512, seed=1):
    return np.random.default_rng(seed).integers(0, 256, size=(h, w, 3), dtype=np.uint8)


def test_textured_image_passes():
    report = ImageQualityService().assess(_noise())
    assert report.passed is True
    assert report.quality_score == 1.0
    assert report.reasons == []


def test_flat_image_fails_sharpness_and_contrast():
    flat = np.full((512, 512, 3), 128, dtype=np.uint8)
    report = ImageQualityService().assess(flat)
    failed = {m.name for m in report.metrics if not m.passed}
    assert "blur_laplacian_variance" in failed
    assert "contrast_std" in failed
    assert report.passed is False
    assert report.quality_score < 1.0


def test_small_image_fails_resolution():
    report = ImageQualityService().assess(_noise(h=64, w=64))
    assert not next(m for m in report.metrics if m.name == "resolution_min_side_px").passed


def test_black_image_fails_brightness_and_occlusion():
    black = np.zeros((512, 512, 3), dtype=np.uint8)
    report = ImageQualityService().assess(black)
    failed = {m.name for m in report.metrics if not m.passed}
    assert "brightness_mean" in failed
    assert "occlusion_ratio" in failed


def test_report_carries_non_clinical_disclaimer():
    report = ImageQualityService().assess(_noise())
    assert report.disclaimer == QUALITY_DISCLAIMER
    assert "not establish clinical validity" in report.disclaimer


def test_decode_rejects_garbage_bytes():
    with pytest.raises(ValueError):
        decode_image(b"definitely not an image")


def test_crop_roi_clamps_and_falls_back():
    img = _noise(100, 200)
    assert crop_roi(img, (10, 10, 50, 40)).shape == (30, 40, 3)
    assert crop_roi(img, (-50, -50, 500, 500)).shape == (100, 200, 3)
    # degenerate box falls back to the full image
    assert crop_roi(img, (50, 50, 10, 10)).shape == (100, 200, 3)
