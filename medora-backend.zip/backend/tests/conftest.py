"""Test environment: isolated DB, uploads, reports and RAG dirs. Must run before the app is imported."""

import io
import os
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="medora-test-"))
os.environ["MEDORA_DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ["MEDORA_UPLOAD_DIR"] = str(_TMP / "uploads")
os.environ["MEDORA_REPORT_DIR"] = str(_TMP / "reports")
os.environ["MEDORA_RAG_DATA_DIR"] = str(_TMP / "rag")
os.environ["MEDORA_MODELS_DIR"] = str(_TMP / "models")  # empty: every model reports MODEL_NOT_CONFIGURED
os.environ["MEDORA_AUTH_ENABLED"] = "false"

import numpy as np  # noqa: E402
import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from PIL import Image  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def textured_png() -> bytes:
    """512x512 random-noise PNG: passes technical quality checks."""
    rng = np.random.default_rng(0)
    arr = rng.integers(0, 256, size=(512, 512, 3), dtype=np.uint8)
    buf = io.BytesIO()
    Image.fromarray(arr).save(buf, format="PNG")
    return buf.getvalue()


@pytest.fixture(scope="session")
def flat_png() -> bytes:
    """Uniform grey PNG: fails sharpness and contrast checks."""
    buf = io.BytesIO()
    Image.new("RGB", (512, 512), (128, 128, 128)).save(buf, format="PNG")
    return buf.getvalue()


@pytest.fixture
def settings():
    return get_settings()
