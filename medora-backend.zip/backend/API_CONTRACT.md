# Medora AI V2: API Contract

Base path: `/api/v1` (configurable with `MEDORA_API_PREFIX`).
All bodies are JSON unless noted. Errors use `{"detail": {"code": "...", "message": "..."}}`
(FastAPI convention) except the LLM and auth placeholders, which return the flat form
`{"code"|"error": "...", "message": "..."}`.

Status of each area:

| Area | Status |
|---|---|
| Health | Implemented |
| Authentication | Architecture-ready. Disabled. Login returns 501. |
| Screening | Implemented. Region models and YOLO return `MODEL_NOT_CONFIGURED` until configured. |
| Results | Implemented |
| Reports | Implemented (structured JSON; no PDF) |
| History | Implemented |
| RAG | Schemas and ingestion implemented. Retrieval returns `EMBEDDER_NOT_CONFIGURED` until an embedder is configured. |
| LLM | **Not implemented.** Returns 501. |

---

## Health

### `GET /health`
```json
{ "status": "ok", "version": "0.1.0", "time": "2026-10-25T13:54:36+00:00" }
```

### `GET /health/ready`
Checks database connectivity. `200 {"status":"ready","database":"ok"}` or `503`.

---

## Authentication

### `GET /auth/status`
```json
{ "auth_enabled": false, "mode": "anonymous", "actor": "anonymous" }
```
When `MEDORA_AUTH_ENABLED=true`, requests need `Authorization: Bearer <token>`. Missing token
returns `401 AUTH_REQUIRED`. Token verification is a placeholder and returns `501`.

### `POST /auth/login`
`501` `{"code":"AUTH_NOT_IMPLEMENTED","message":"..."}`

---

## Screening

### `POST /screenings`
`multipart/form-data`

| Field | Type | Required | Notes |
|---|---|---|---|
| `region` | string | yes | `eye`, `skin`, `nails`, `mouth` (case-insensitive) |
| `image` | file | yes | JPEG or PNG. Max `MEDORA_MAX_UPLOAD_BYTES` (default 10 MB) |
| `symptoms` | string | no | Comma-separated snake_case codes, max 500 chars. Only known red-flag codes affect risk. |

Response `201`:
```json
{ "screening_id": "3f1c...", "status": "completed" }
```
`status` is the lifecycle state: `completed` or `failed`. The clinical-style outcome is in
`GET /screenings/{id}` under `risk`.

Errors:

| HTTP | code | Cause |
|---|---|---|
| 413 | `FILE_TOO_LARGE` | Over size limit |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | Declared type not JPEG/PNG |
| 415 | `INVALID_IMAGE` | Bytes are not a valid image |
| 415 | `CONTENT_TYPE_MISMATCH` | Declared type differs from actual format |
| 422 | `UNSUPPORTED_REGION` | Region not in the four supported values |
| 422 | `EMPTY_FILE` | Zero bytes |
| 422 | `IMAGE_DECODE_FAILED` | Image cannot be decoded |
| 500 | `PIPELINE_ERROR` | Internal failure. The screening row is marked `failed`. |

Example:
```bash
curl -X POST http://127.0.0.1:8000/api/v1/screenings \
  -F region=skin -F "image=@./photo.jpg;type=image/jpeg" -F "symptoms=rapidly_changing_mole"
```

---

## Results

### `GET /screenings/{screening_id}`
Returns the stored structured result.

```json
{
  "screening_id": "3f1c...",
  "body_region": "eye",
  "status": "completed",
  "image_quality": {
    "quality_score": 1.0,
    "passed": true,
    "metrics": [
      {"name": "resolution_min_side_px", "value": 512.0, "threshold": ">= 224", "passed": true},
      {"name": "blur_laplacian_variance", "value": 5321.4, "threshold": ">= 50.0", "passed": true},
      {"name": "brightness_mean", "value": 127.8, "threshold": "40.0 to 220.0", "passed": true},
      {"name": "contrast_std", "value": 74.1, "threshold": ">= 20.0", "passed": true},
      {"name": "occlusion_ratio", "value": 0.08, "threshold": "<= 0.5", "passed": true}
    ],
    "reasons": [],
    "disclaimer": "Technical image-quality checks only. ..."
  },
  "detection": {"status": "MODEL_NOT_CONFIGURED", "message": "No YOLO weights configured (...)",
                "detections": [], "roi_extracted": false},
  "prediction": {"status": "MODEL_NOT_CONFIGURED", "region": "eye", "label": null,
                 "model_confidence": null, "severity_hint": null, "model_version": null,
                 "raw": null, "message": "No weights for 'eye' at ..."},
  "risk": {
    "risk_level": null,
    "screening_status": "MODEL_NOT_CONFIGURED",
    "urgency": "no_image_assessment_available",
    "reason_codes": ["MODEL_NOT_CONFIGURED"],
    "thresholds_version": "config-placeholder-v1 (not clinically validated)"
  },
  "specialist": {"specialty": "Ophthalmology", "professional": "Ophthalmologist or optometrist",
                 "mapping_key": "eye", "source": "region_default", "mapping_version": "draft-1"},
  "evidence": {"retrieval_status": "EMBEDDER_NOT_CONFIGURED", "items": [],
               "image_embedding": {"status": "MODEL_NOT_CONFIGURED"}},
  "report": { "...": "same structure as GET /screenings/{id}/report" }
}
```

Fields that are not yet computed are `null`. A `risk_level` of `null` means no assessment was
possible, not "no risk".

`risk_level` values: `GREEN`, `BLUE`, `AMBER`, `RED`, or `null`.

`screening_status` values: `COMPLETED`, `RETAKE_REQUIRED`, `MODEL_NOT_CONFIGURED`.

`urgency` values: `seek_prompt_professional_review`, `seek_professional_review_soon`,
`monitor_and_recheck`, `routine_monitoring`, `retake_image`, `no_image_assessment_available`,
`no_severity_signal_available`, `no_assessment_available`.

Errors: `404 {"detail":{"code":"NOT_FOUND"}}`.

---

## Reports

### `GET /screenings/{screening_id}/report`
Structured JSON report (no PDF).

```json
{
  "screening_id": "3f1c...",
  "body_region": "eye",
  "finding": {"status": "MODEL_NOT_CONFIGURED", "label": null, "message": "..."},
  "model_confidence": null,
  "image_quality": {"...": "..."},
  "risk": {"...": "..."},
  "specialist": {"...": "..."},
  "urgency": "no_image_assessment_available",
  "possible_causes": {"status": "NO_EVIDENCE", "items": []},
  "prevention": {"status": "NO_EVIDENCE", "items": []},
  "general_care": {"status": "NO_EVIDENCE", "items": []},
  "evidence": {"...": "..."},
  "disclaimer": "This is an informational screening aid. It is not a diagnosis ...",
  "generated_by": "report_service/v1 (deterministic, no LLM)"
}
```

Errors: `404` when no report exists for the screening.

---

## History

### `GET /history?limit=20&offset=0`
`limit` 1 to 100 (default 20). `offset` 0 or more. Newest first.

```json
{
  "items": [
    {"screening_id": "3f1c...", "body_region": "eye", "status": "completed",
     "risk_level": null, "created_at": "2026-10-25T13:55:02.123456+00:00"}
  ],
  "limit": 20,
  "offset": 0
}
```

---

## RAG (internal contract, no public endpoint yet)

Parquet tables in `rag_data/parquet/`:
`conditions, causes, prevention, care, risk_factors, specialists, symptoms, red_flags, guidelines, sources`.

Every knowledge table carries provenance fields:
`body_region, description, evidence_level, source_id, source_title, source_type, publication_date,
organization, url_or_doi, text`, plus its own id field (`condition_id`, `cause_id`, ...).
`sources` holds the source registry.

Retrieval result, as embedded in `evidence`:
```json
{ "status": "OK | NO_EVIDENCE | EMBEDDER_NOT_CONFIGURED | SKIPPED",
  "items": [{"source_id": "...", "source_title": "...", "text": "...", "score": 0.0,
             "url_or_doi": "...", "evidence_level": "..."}] }
```

---

## LLM placeholder

### `POST /llm/generate`

Request:
```json
{
  "system_instruction": "string, max 8000",
  "context": [{"source_id": "string|null", "text": "string, max 4000"}],
  "user_input": "string, 1 to 8000",
  "structured_data": {}
}
```

Current response, always:
```http
HTTP/1.1 501 Not Implemented
{"error": "NOT_IMPLEMENTED", "message": "No LLM provider is connected. See app/llm/README.md to implement one."}
```

Intended response once a provider is implemented:
```json
{
  "text": "string",
  "citations": [{"source_id": "string|null", "title": "string|null", "url_or_doi": "string|null"}],
  "model": "string",
  "usage": {}
}
```

Invalid request bodies return `422` before the 501 check.

---

## Not part of this contract

- Frontend integration, CORS origins, and frontend fetch code.
- Any external LLM call, or any API key.
- PDF rendering.
