# LLM layer

Status: **NOT IMPLEMENTED. NOT CONNECTED.**
`POST /api/v1/llm/generate` returns `501 NOT_IMPLEMENTED` until a provider is attached.
The backend never substitutes a fake or template answer.

## 1. Where to implement the provider
Create a module such as `app/llm/providers/<name>.py`. Do not put provider code in
`interface.py`, `adapter.py`, or `schemas.py`.

## 2. Which interface to implement
`app.llm.interface.LLMProvider`, which defines:
```python
class LLMProvider(ABC):
    name: str
    @abstractmethod
    def generate(self, request: LLMRequest) -> LLMResponse: ...
```

## 3. How the backend calls the provider
`get_llm_adapter()` in `app/llm/adapter.py` returns `LLMAdapter(provider=None)`.
Change that one line to pass your provider instance. The route handler calls
`adapter.generate(request)`. If no provider is attached it raises
`LLMNotImplementedError`, which the route maps to HTTP 501.

## 4. Expected request schema (`app/llm/schemas.py: LLMRequest`)
```json
{
  "system_instruction": "string, max 8000 chars",
  "context": [{"source_id": "string|null", "text": "string, max 4000 chars"}],
  "user_input": "string, 1 to 8000 chars",
  "structured_data": {}
}
```

## 5. Expected response schema (`LLMResponse`)
```json
{
  "text": "string",
  "citations": [{"source_id": "...", "title": "...", "url_or_doi": "..."}],
  "model": "string",
  "usage": {}
}
```

## 6. Environment variables
None are defined yet. When you add a provider, add its variables to `.env.example`
with placeholder values only. Read them through `app/core/config.py`.

## 7. Security rules
- API keys come from environment variables or a secrets manager. Never hard-code or commit them.
- The LLM must not invent specialist mappings, diagnoses, or severity levels. Those come from
  `app/risk/` and the curated JSON files.
- Pass only retrieved, cited evidence in `context`. Do not send raw images or patient identifiers.
- Log request IDs and token counts, not prompt bodies that contain user data.

## 8. How to replace the provider
1. Implement `LLMProvider` in a new module.
2. In `get_llm_adapter()`, return `LLMAdapter(provider=YourProvider(...))`.
3. Do not change any route, schema, or the `/api/v1/llm/generate` contract.

## 9. How to test with a local mock provider
`tests/test_llm_placeholder.py` shows the pattern. Override the dependency:
```python
app.dependency_overrides[get_llm_adapter] = lambda: LLMAdapter(MockProvider())
```
where `MockProvider.generate` returns a fixed `LLMResponse`. Remove the override in
teardown. The mock must never be wired into production code.

## 10. Connecting the future LLM without changing frontend contracts
The request and response shapes above are the contract. The frontend should only ever
see `LLMResponse`. Keep the provider behind the adapter so a provider swap needs no
frontend change.
