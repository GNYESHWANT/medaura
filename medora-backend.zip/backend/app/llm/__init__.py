"""LLM layer. Interface, schemas and adapter only. NOT implemented, NOT connected."""
