"""LLM request/response contract. Frozen API surface; the provider behind it is not implemented."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ContextItem(BaseModel):
    source_id: str | None = None
    text: str = Field(max_length=4000)


class LLMRequest(BaseModel):
    system_instruction: str = Field(max_length=8000)
    context: list[ContextItem] = Field(default_factory=list, max_length=50)
    user_input: str = Field(min_length=1, max_length=8000)
    structured_data: dict[str, Any] = Field(default_factory=dict)


class Citation(BaseModel):
    source_id: str | None = None
    title: str | None = None
    url_or_doi: str | None = None


class LLMResponse(BaseModel):
    text: str
    citations: list[Citation] = Field(default_factory=list)
    model: str
    usage: dict[str, Any] = Field(default_factory=dict)
