"""Contract that any future LLM provider must implement. No provider is implemented here."""

from __future__ import annotations

from abc import ABC, abstractmethod

from app.llm.schemas import LLMRequest, LLMResponse


class LLMNotImplementedError(RuntimeError):
    """Raised when no LLM provider is connected. Never replaced with a fake answer."""


class LLMProvider(ABC):
    name: str = "unnamed"

    @abstractmethod
    def generate(self, request: LLMRequest) -> LLMResponse:
        """Produce a grounded answer from the request. Must not invent specialist mappings or diagnoses."""
