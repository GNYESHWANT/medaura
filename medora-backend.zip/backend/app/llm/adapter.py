"""Adapter the API calls. With no provider attached it refuses instead of substituting anything."""

from __future__ import annotations

from app.llm.interface import LLMNotImplementedError, LLMProvider
from app.llm.schemas import LLMRequest, LLMResponse


class LLMAdapter:
    def __init__(self, provider: LLMProvider | None = None) -> None:
        self._provider = provider

    @property
    def is_configured(self) -> bool:
        return self._provider is not None

    def generate(self, request: LLMRequest) -> LLMResponse:
        if self._provider is None:
            raise LLMNotImplementedError(
                "No LLM provider is connected. See app/llm/README.md to implement one."
            )
        return self._provider.generate(request)


def get_llm_adapter() -> LLMAdapter:
    # Intentionally empty. Wire a provider here when the LLM is implemented.
    return LLMAdapter(provider=None)
