from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ScreeningResult(BaseModel):
    """Structured result. Section payloads are validated upstream by their owning service."""

    screening_id: str
    body_region: str
    status: str
    image_quality: dict[str, Any] | None = None
    detection: dict[str, Any] | None = None
    prediction: dict[str, Any] | None = None
    risk: dict[str, Any] | None = None
    specialist: dict[str, Any] | None = None
    evidence: dict[str, Any] | None = None
    report: dict[str, Any] | None = None
