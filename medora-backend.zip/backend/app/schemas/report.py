from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ReportOut(BaseModel):
    screening_id: str
    body_region: str
    finding: dict[str, Any]
    model_confidence: float | None
    image_quality: dict[str, Any]
    risk: dict[str, Any]
    specialist: dict[str, Any]
    urgency: str
    possible_causes: dict[str, Any]
    prevention: dict[str, Any]
    general_care: dict[str, Any]
    evidence: dict[str, Any]
    disclaimer: str
    generated_by: str
