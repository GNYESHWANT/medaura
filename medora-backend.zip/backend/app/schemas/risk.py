from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

RiskLevel = Literal["GREEN", "BLUE", "AMBER", "RED"]


class RiskOut(BaseModel):
    risk_level: RiskLevel | None = Field(None, description="None when no assessment is possible")
    screening_status: Literal["COMPLETED", "RETAKE_REQUIRED", "MODEL_NOT_CONFIGURED"]
    urgency: str
    reason_codes: list[str] = Field(default_factory=list)
    thresholds_version: str
