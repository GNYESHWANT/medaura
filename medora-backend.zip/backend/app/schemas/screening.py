from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

BodyRegion = Literal["eye", "skin", "nails", "mouth"]


class ScreeningCreated(BaseModel):
    screening_id: str
    status: Literal["processing", "completed", "failed"]


class ErrorBody(BaseModel):
    code: str
    message: str
