"""Retrieval abstractions: VectorStore, Retriever. Stubs until a vector index is connected."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field

from app.models.base import ModelNotConfigured
from app.rag.embed import EmbeddingProvider, NotConfiguredEmbeddingProvider
from app.rag.rerank import PassthroughReranker, Reranker


@dataclass
class EvidenceItem:
    source_id: str
    source_title: str
    text: str
    score: float
    url_or_doi: str | None = None
    evidence_level: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RetrievalResult:
    status: str  # OK | NO_EVIDENCE | EMBEDDER_NOT_CONFIGURED | SKIPPED
    items: list[EvidenceItem] = field(default_factory=list)


class VectorStore(ABC):
    @abstractmethod
    def search(self, vector: list[float], body_region: str, top_k: int) -> list[EvidenceItem]:
        """Nearest-neighbour search restricted to a body region."""


class NullVectorStore(VectorStore):
    def search(self, vector: list[float], body_region: str, top_k: int) -> list[EvidenceItem]:
        return []


class Retriever:
    def __init__(self, embedder: EmbeddingProvider, store: VectorStore, reranker: Reranker) -> None:
        self.embedder = embedder
        self.store = store
        self.reranker = reranker

    def retrieve(self, query: str, body_region: str, top_k: int = 5) -> RetrievalResult:
        try:
            vector = self.embedder.embed_texts([query])[0]
        except ModelNotConfigured:
            return RetrievalResult(status="EMBEDDER_NOT_CONFIGURED")
        items = self.store.search(vector, body_region, top_k)
        items = self.reranker.rerank(query, items)
        return RetrievalResult(status="OK" if items else "NO_EVIDENCE", items=items)


def build_default_retriever() -> Retriever:
    return Retriever(NotConfiguredEmbeddingProvider(), NullVectorStore(), PassthroughReranker())
