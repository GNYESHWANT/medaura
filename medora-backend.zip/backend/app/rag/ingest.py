"""Writes curated knowledge rows into the canonical Parquet tables.

Usage (creates empty, schema-valid tables if missing):
    python -m app.rag.ingest
"""

from __future__ import annotations

from pathlib import Path

from app.core.config import get_settings
from app.rag.parquet import TABLES, write_table


def ensure_empty_tables(root: Path | None = None) -> list[Path]:
    root = (root or get_settings().rag_data_dir) / "parquet"
    written = []
    for table in TABLES:
        path = root / f"{table}.parquet"
        if not path.exists():
            written.append(write_table(table, [], root))
    return written


def ingest_rows(table: str, rows: list[dict], root: Path | None = None) -> Path:
    """Validate and write rows. Curated, reviewed content only. The LLM never writes here."""
    root = (root or get_settings().rag_data_dir) / "parquet"
    return write_table(table, rows, root)


if __name__ == "__main__":
    for path in ensure_empty_tables():
        print(f"created {path}")
