"""Shared RAG constants. Kept separate to avoid import cycles."""

from app.vision.router import SUPPORTED_REGIONS

BODY_REGIONS: tuple[str, ...] = SUPPORTED_REGIONS
