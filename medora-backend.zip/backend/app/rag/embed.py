"""Text-embedding interface. No provider is configured in this build."""

from __future__ import annotations

from abc import ABC, abstractmethod

from app.models.base import ModelNotConfigured


class EmbeddingProvider(ABC):
    @abstractmethod
    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Return one vector per input text."""


class NotConfiguredEmbeddingProvider(EmbeddingProvider):
    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        raise ModelNotConfigured("Text embedding provider is not configured")
