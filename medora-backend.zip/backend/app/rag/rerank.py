"""Reranker interface. The default passes results through unchanged."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.rag.retrieve import EvidenceItem


class Reranker(ABC):
    @abstractmethod
    def rerank(self, query: str, items: list[EvidenceItem]) -> list[EvidenceItem]:
        """Return items re-ordered by relevance to the query."""


class PassthroughReranker(Reranker):
    def rerank(self, query: str, items: list[EvidenceItem]) -> list[EvidenceItem]:
        return list(items)
