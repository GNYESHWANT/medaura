"""Parquet is the CANONICAL structured medical-knowledge store.

It is NOT a vector database. Retrieval is handled by the abstractions in
retrieve.py, which can sit on top of any vector index.
"""

from __future__ import annotations

from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from app.rag.schema import BODY_REGIONS

_S = pa.string()

# Source-citation and governance fields shared by every knowledge table.
_COMMON: list[tuple[str, pa.DataType]] = [
    ("body_region", _S),
    ("description", _S),
    ("evidence_level", _S),
    ("source_id", _S),
    ("source_title", _S),
    ("source_type", _S),
    ("publication_date", _S),
    ("organization", _S),
    ("url_or_doi", _S),
    ("text", _S),
]

TABLES: dict[str, list[tuple[str, pa.DataType]]] = {
    "conditions": [("condition_id", _S), ("condition_name", _S)] + _COMMON,
    "causes": [("cause_id", _S), ("condition_id", _S), ("cause_name", _S)] + _COMMON,
    "prevention": [("prevention_id", _S), ("condition_id", _S), ("measure", _S)] + _COMMON,
    "care": [("care_id", _S), ("condition_id", _S), ("care_advice", _S)] + _COMMON,
    "risk_factors": [("risk_factor_id", _S), ("condition_id", _S), ("factor_name", _S)] + _COMMON,
    "specialists": [("specialist_id", _S), ("condition_id", _S), ("specialty", _S), ("when_to_refer", _S)] + _COMMON,
    "symptoms": [("symptom_id", _S), ("condition_id", _S), ("symptom_name", _S)] + _COMMON,
    "red_flags": [("red_flag_id", _S), ("condition_id", _S), ("red_flag_name", _S), ("urgency", _S)] + _COMMON,
    "guidelines": [("guideline_id", _S), ("condition_id", _S), ("guideline_title", _S)] + _COMMON,
    "sources": [
        ("source_id", _S),
        ("source_title", _S),
        ("source_type", _S),
        ("publication_date", _S),
        ("organization", _S),
        ("url_or_doi", _S),
        ("evidence_level", _S),
    ],
}

ID_FIELD: dict[str, str] = {
    "conditions": "condition_id",
    "causes": "cause_id",
    "prevention": "prevention_id",
    "care": "care_id",
    "risk_factors": "risk_factor_id",
    "specialists": "specialist_id",
    "symptoms": "symptom_id",
    "red_flags": "red_flag_id",
    "guidelines": "guideline_id",
    "sources": "source_id",
}


def schema_for(table: str) -> pa.Schema:
    if table not in TABLES:
        raise ValueError(f"Unknown RAG table '{table}'")
    return pa.schema(TABLES[table])


def validate_rows(table: str, rows: list[dict]) -> None:
    schema = schema_for(table)
    allowed = set(schema.names)
    id_field = ID_FIELD[table]
    for index, row in enumerate(rows):
        unknown = set(row) - allowed
        if unknown:
            raise ValueError(f"{table}[{index}]: unknown fields {sorted(unknown)}")
        if not row.get(id_field):
            raise ValueError(f"{table}[{index}]: '{id_field}' is required")
        region = row.get("body_region")
        if region is not None and region not in BODY_REGIONS:
            raise ValueError(f"{table}[{index}]: body_region '{region}' is not supported")


def write_table(table: str, rows: list[dict], root: Path) -> Path:
    validate_rows(table, rows)
    schema = schema_for(table)
    arrays = {name: [row.get(name) for row in rows] for name in schema.names}
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{table}.parquet"
    pq.write_table(pa.table(arrays, schema=schema), path)
    return path


def read_table(table: str, root: Path) -> pa.Table:
    return pq.read_table(root / f"{table}.parquet", schema=schema_for(table))
