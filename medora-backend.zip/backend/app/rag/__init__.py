"""RAG layer: Parquet knowledge store, ingestion, embedding and retrieval interfaces."""
