"""Application services: screening orchestration, image handling, reports, history."""
