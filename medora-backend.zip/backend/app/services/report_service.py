"""Deterministic structured report builder. No LLM is involved.

PDF rendering, if added later, should consume this JSON as a separate service.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.models.base import STATUS_OK, ModelPrediction

REPORT_DISCLAIMER = (
    "This is an informational screening aid. It is not a diagnosis and does not replace "
    "examination by a qualified health professional. If you have a concern, or any red-flag "
    "symptom, seek professional care."
)
GENERATED_BY = "report_service/v1 (deterministic, no LLM)"


def _unavailable(reason: str) -> dict[str, Any]:
    return {"status": reason, "items": []}


def build_report(
    *,
    screening_id: str,
    region: str,
    quality: dict,
    prediction: ModelPrediction,
    risk: dict,
    specialist: dict,
    evidence: dict,
) -> dict:
    has_finding = prediction.status == STATUS_OK
    evidence_items = evidence.get("items", [])
    return {
        "screening_id": screening_id,
        "body_region": region,
        "finding": {
            "status": prediction.status,
            "label": prediction.label if has_finding else None,
            "message": prediction.message,
        },
        "model_confidence": prediction.model_confidence if has_finding else None,
        "image_quality": quality,
        "risk": risk,
        "specialist": specialist,
        "urgency": risk["urgency"],
        "possible_causes": _unavailable("NO_EVIDENCE" if not evidence_items else "NOT_CURATED_YET"),
        "prevention": _unavailable("NO_EVIDENCE" if not evidence_items else "NOT_CURATED_YET"),
        "general_care": _unavailable("NO_EVIDENCE" if not evidence_items else "NOT_CURATED_YET"),
        "evidence": evidence,
        "disclaimer": REPORT_DISCLAIMER,
        "generated_by": GENERATED_BY,
    }


def persist_report(report_dir: Path, screening_id: str, report: dict) -> Path:
    report_dir.mkdir(parents=True, exist_ok=True)
    path = report_dir / f"{screening_id}.json"
    path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    return path
