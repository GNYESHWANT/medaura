"""Upload validation and storage. Client-supplied names never become filesystem paths."""

from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from fastapi import UploadFile
from PIL import Image as PILImage

from app.core.config import Settings, get_settings
from app.core.security import new_stored_name, safe_filename
from app.vision.preprocessing import decode_image

ALLOWED_CONTENT_TYPES: dict[str, str] = {"image/jpeg": "JPEG", "image/png": "PNG"}
EXTENSIONS: dict[str, str] = {"JPEG": ".jpg", "PNG": ".png"}
_READ_CHUNK = 64 * 1024


class ValidationFailure(Exception):
    def __init__(self, http_status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.http_status = http_status
        self.code = code
        self.message = message


@dataclass(frozen=True)
class StoredImage:
    stored_name: str
    original_name: str
    mime_type: str
    width: int
    height: int
    size_bytes: int
    sha256: str
    path: Path


def _read_limited(upload: UploadFile, limit: int) -> bytes:
    upload.file.seek(0)
    buffer = io.BytesIO()
    while True:
        chunk = upload.file.read(_READ_CHUNK)
        if not chunk:
            break
        buffer.write(chunk)
        if buffer.tell() > limit:
            raise ValidationFailure(413, "FILE_TOO_LARGE", f"Upload exceeds {limit} bytes")
    return buffer.getvalue()


def load_validated_image(upload: UploadFile, settings: Settings | None = None) -> tuple[bytes, np.ndarray, str]:
    """Validate type, size and content. Returns (raw bytes, decoded BGR image, PIL format)."""
    s = settings or get_settings()

    declared = (upload.content_type or "").lower()
    if declared not in ALLOWED_CONTENT_TYPES:
        raise ValidationFailure(415, "UNSUPPORTED_MEDIA_TYPE", "Only JPEG and PNG images are accepted")

    data = _read_limited(upload, s.max_upload_bytes)
    if not data:
        raise ValidationFailure(422, "EMPTY_FILE", "Uploaded file is empty")

    try:
        with PILImage.open(io.BytesIO(data)) as probe:
            probe.verify()
            fmt = probe.format
    except Exception as exc:  # PIL raises several types; all mean "not a valid image"
        raise ValidationFailure(415, "INVALID_IMAGE", "File is not a valid image") from exc

    if fmt not in s.allowed_formats or ALLOWED_CONTENT_TYPES[declared] != fmt:
        raise ValidationFailure(415, "CONTENT_TYPE_MISMATCH", "File content does not match its declared type")

    try:
        image = decode_image(data)
    except ValueError as exc:
        raise ValidationFailure(422, "IMAGE_DECODE_FAILED", "Image could not be decoded") from exc

    return data, image, fmt


def store_image(data: bytes, fmt: str, original_filename: str | None, settings: Settings | None = None) -> StoredImage:
    s = settings or get_settings()
    with PILImage.open(io.BytesIO(data)) as im:
        width, height = im.size
    stored_name = new_stored_name(EXTENSIONS[fmt])
    s.upload_dir.mkdir(parents=True, exist_ok=True)
    path = s.upload_dir / stored_name
    path.write_bytes(data)
    return StoredImage(
        stored_name=stored_name,
        original_name=safe_filename(original_filename),
        mime_type=f"image/{fmt.lower()}",
        width=width,
        height=height,
        size_bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        path=path,
    )
