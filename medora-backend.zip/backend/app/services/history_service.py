"""History listing. Scoped to the actor once authentication is enabled."""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.database.repository import ScreeningRepository


def list_history(db: Session, limit: int, offset: int) -> list[dict]:
    rows = ScreeningRepository(db).list_history(limit=limit, offset=offset)
    return [
        {
            "screening_id": r.id,
            "body_region": r.body_region,
            "status": r.status,
            "risk_level": r.risk_level,
            "created_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]
