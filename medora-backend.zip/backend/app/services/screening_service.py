"""Screening orchestration.

Pipeline:
  validate upload -> decode -> image quality -> YOLO (ROI) -> region model
  -> embedding status -> RAG retrieval -> red flags -> triage -> specialist
  -> report -> persist
"""

from __future__ import annotations

import re
from dataclasses import asdict

from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.core.logging import get_logger
from app.database.models import Screening
from app.database.repository import ScreeningRepository
from app.models.base import MODEL_NOT_CONFIGURED, ModelNotConfigured, ModelPrediction, RegionModel
from app.risk import triage
from app.risk.red_flags import RedFlagRegistry
from app.risk.specialist import SpecialistRouter
from app.rag.retrieve import RetrievalResult, Retriever, build_default_retriever
from app.services.image_service import ValidationFailure, load_validated_image, store_image
from app.services.report_service import build_report, persist_report
from app.vision.embeddings import ImageEmbedder, get_image_embedder
from app.vision.preprocessing import to_model_input
from app.vision.quality import ImageQualityService
from app.vision.router import UnsupportedRegion, build_region_models, normalize_region
from app.vision.yolo import DetectionResult, YoloDetector

logger = get_logger(__name__)

_SYMPTOM_CODE = re.compile(r"^[a-z0-9_]{1,64}$")
MAX_SYMPTOMS = 20


class ScreeningPipelineError(RuntimeError):
    pass


def parse_symptoms(raw: str | None) -> set[str]:
    """Accept comma-separated snake_case codes. Anything else is dropped."""
    if not raw:
        return set()
    codes = {part.strip().lower() for part in raw.split(",")[:MAX_SYMPTOMS]}
    return {c for c in codes if _SYMPTOM_CODE.match(c)}


class ScreeningService:
    def __init__(
        self,
        db: Session,
        settings: Settings | None = None,
        *,
        quality: ImageQualityService | None = None,
        detector: YoloDetector | None = None,
        models: dict[str, RegionModel] | None = None,
        embedder: ImageEmbedder | None = None,
        retriever: Retriever | None = None,
        specialists: SpecialistRouter | None = None,
        red_flags: RedFlagRegistry | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.repo = ScreeningRepository(db)
        self.quality = quality or ImageQualityService(self.settings)
        self.detector = detector or YoloDetector(self.settings.yolo_weights_path, self.settings.yolo_confidence)
        self.models = models or build_region_models(self.settings.models_dir)
        self.embedder = embedder or get_image_embedder()
        self.retriever = retriever or build_default_retriever()
        self.specialists = specialists or SpecialistRouter()
        self.red_flags = red_flags or RedFlagRegistry()

    def run(self, *, region_raw: str, upload, symptoms_raw: str, actor_id: str, authenticated: bool = False) -> Screening:
        """Raises UnsupportedRegion, ValidationFailure or ScreeningPipelineError."""
        region = normalize_region(region_raw)

        try:
            data, image, fmt = load_validated_image(upload, self.settings)
        except ValidationFailure as exc:
            self.repo.audit(actor_id, "upload.rejected", "upload", None, {"code": exc.code, "region": region})
            raise

        stored = store_image(data, fmt, upload.filename, self.settings)
        screening = self.repo.create_screening(region, user_id=actor_id if authenticated else None)
        self.repo.audit(actor_id, "screening.created", "screening", screening.id,
                        {"region": region, "size_bytes": stored.size_bytes})

        try:
            result = self._pipeline(screening.id, region, stored, image, symptoms_raw)
        except UnsupportedRegion:
            raise
        except Exception:
            logger.exception("Screening pipeline failed for screening %s", screening.id)
            self.repo.fail(screening, "PIPELINE_ERROR")
            self.repo.audit(actor_id, "screening.failed", "screening", screening.id, {"code": "PIPELINE_ERROR"})
            raise ScreeningPipelineError(screening.id) from None

        screening = self.repo.finish(screening, risk_level=result["risk"]["risk_level"], result=result)
        self.repo.audit(actor_id, "screening.completed", "screening", screening.id,
                        {"risk_level": result["risk"]["risk_level"]})
        return screening

    def _pipeline(self, screening_id: str, region: str, stored, image, symptoms_raw: str) -> dict:
        quality = self.quality.assess(image)
        self.repo.add_image(screening_id, stored=stored, quality=quality)

        if quality.passed:
            detection: DetectionResult = self.detector.detect(image)
            target = detection.roi if detection.roi is not None else image
            prediction: ModelPrediction = self._predict(region, target)
            embedding_status = self._embedding_status(target)
            retrieval: RetrievalResult = self.retriever.retrieve(
                f"{region} image screening {prediction.label or 'no finding'}", region
            )
        else:
            detection = DetectionResult(status="SKIPPED", detections=[], roi=None,
                                        message="Image quality failed; detection skipped.")
            prediction = ModelPrediction(status="SKIPPED", region=region,
                                         message="Image quality failed; model not run.")
            embedding_status = "SKIPPED"
            retrieval = RetrievalResult(status="SKIPPED")

        flags = self.red_flags.check(region, parse_symptoms(symptoms_raw))
        risk = triage.assess(
            quality_passed=quality.passed,
            prediction=prediction if quality.passed else None,
            red_flags=flags,
            evidence_count=len(retrieval.items),
            settings=self.settings,
        )

        finding = prediction.label if prediction.status == "OK" else None
        specialist = self.specialists.route(region, finding)

        evidence = {
            "retrieval_status": retrieval.status,
            "items": [item.to_dict() for item in retrieval.items],
            "image_embedding": {"status": embedding_status},
        }
        quality_dict = quality.to_dict()
        prediction_dict = asdict(prediction)
        detection_dict = detection.to_dict()
        risk_dict = risk.to_dict()
        specialist_dict = specialist.to_dict()

        report = build_report(
            screening_id=screening_id, region=region, quality=quality_dict, prediction=prediction,
            risk=risk_dict, specialist=specialist_dict, evidence=evidence,
        )
        report_path = persist_report(self.settings.report_dir, screening_id, report)

        self.repo.add_prediction(screening_id, region, detection_dict, prediction_dict)
        self.repo.add_risk(screening_id, risk_dict)
        self.repo.add_report(screening_id, report_path)

        return {
            "screening_id": screening_id,
            "body_region": region,
            "status": "completed",
            "image_quality": quality_dict,
            "detection": detection_dict,
            "prediction": prediction_dict,
            "risk": risk_dict,
            "specialist": specialist_dict,
            "evidence": evidence,
            "report": report,
        }

    def _predict(self, region: str, image) -> ModelPrediction:
        # 224 px is a placeholder input size; each real model should declare its own.
        return self.models[region].predict(to_model_input(image, 224))

    def _embedding_status(self, image) -> str:
        try:
            self.embedder.embed(image)
            return "OK"
        except ModelNotConfigured:
            return MODEL_NOT_CONFIGURED
