"""Repository layer: all DB access for screenings goes through here."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database.models import AuditLog, Image, Prediction, Report, RiskAssessment, Screening


class ScreeningRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create_screening(self, body_region: str, user_id: str | None = None) -> Screening:
        screening = Screening(body_region=body_region, status="processing", user_id=user_id)
        self.db.add(screening)
        self.db.commit()
        self.db.refresh(screening)
        return screening

    def add_image(self, screening_id: str, *, stored: Any, quality: Any) -> Image:
        image = Image(
            screening_id=screening_id,
            stored_name=stored.stored_name,
            original_name=stored.original_name,
            mime_type=stored.mime_type,
            width=stored.width,
            height=stored.height,
            size_bytes=stored.size_bytes,
            sha256=stored.sha256,
            quality_score=quality.quality_score,
            quality_json=json.dumps(quality.to_dict()),
        )
        self.db.add(image)
        self.db.commit()
        return image

    def add_prediction(self, screening_id: str, body_region: str, detection: dict, prediction: dict) -> Prediction:
        row = Prediction(
            screening_id=screening_id,
            body_region=body_region,
            status=prediction["status"],
            label=prediction.get("label"),
            model_confidence=prediction.get("model_confidence"),
            model_version=prediction.get("model_version"),
            detection_json=json.dumps(detection, default=str),
            prediction_json=json.dumps(prediction, default=str),
        )
        self.db.add(row)
        self.db.commit()
        return row

    def add_risk(self, screening_id: str, risk: dict) -> RiskAssessment:
        row = RiskAssessment(
            screening_id=screening_id,
            risk_level=risk["risk_level"],
            screening_status=risk["screening_status"],
            urgency=risk["urgency"],
            reason_codes=json.dumps(risk["reason_codes"]),
            thresholds_version=risk["thresholds_version"],
        )
        self.db.add(row)
        self.db.commit()
        return row

    def add_report(self, screening_id: str, file_path: Path) -> Report:
        row = Report(screening_id=screening_id, file_path=str(file_path))
        self.db.add(row)
        self.db.commit()
        return row

    def finish(self, screening: Screening, *, risk_level: str | None, result: dict) -> Screening:
        screening.status = "completed"
        screening.risk_level = risk_level
        screening.result_json = json.dumps(result, default=str)
        self.db.commit()
        self.db.refresh(screening)
        return screening

    def fail(self, screening: Screening, error_code: str) -> Screening:
        screening.status = "failed"
        screening.error_code = error_code
        self.db.commit()
        return screening

    def get_screening(self, screening_id: str) -> Screening | None:
        return self.db.get(Screening, screening_id)

    def get_report(self, screening_id: str) -> Report | None:
        return self.db.execute(
            select(Report).where(Report.screening_id == screening_id).order_by(Report.created_at.desc())
        ).scalars().first()

    def list_history(self, limit: int, offset: int) -> list[Screening]:
        stmt = select(Screening).order_by(Screening.created_at.desc()).limit(limit).offset(offset)
        return list(self.db.execute(stmt).scalars())

    def audit(self, actor_id: str, action: str, entity_type: str, entity_id: str | None, detail: dict) -> None:
        self.db.add(
            AuditLog(
                actor_id=actor_id,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                detail_json=json.dumps(detail, default=str),
            )
        )
        self.db.commit()
