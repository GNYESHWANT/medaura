"""Security helpers: filename sanitisation, auth-ready actor dependency.

Authentication is architecture-ready but NOT implemented. With auth disabled,
every request is attributed to an anonymous actor. With auth enabled, a bearer
token is required and verify_token() must be implemented by the auth provider.
"""

from __future__ import annotations

import re
import uuid

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from app.core.config import get_settings

_UNSAFE_CHARS = re.compile(r"[^A-Za-z0-9._-]")


class Actor(BaseModel):
    id: str
    authenticated: bool


ANONYMOUS = Actor(id="anonymous", authenticated=False)


def safe_filename(original: str | None, max_len: int = 64) -> str:
    """Reduce a client-supplied filename to a safe ASCII basename. Never used as a path."""
    name = (original or "upload").replace("\\", "/").split("/")[-1]
    name = _UNSAFE_CHARS.sub("_", name)[:max_len].strip("._")
    return name or "upload"


def new_stored_name(extension: str) -> str:
    """Server-generated storage name. Client filenames never touch the filesystem path."""
    return f"{uuid.uuid4().hex}{extension}"


def verify_token(token: str) -> Actor:
    """Placeholder. Replace with the real token/session verification."""
    raise HTTPException(
        status_code=501,
        detail={"code": "AUTH_NOT_IMPLEMENTED", "message": "Token verification is not implemented."},
    )


_bearer = HTTPBearer(auto_error=False)


def get_current_actor(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> Actor:
    if not get_settings().auth_enabled:
        return ANONYMOUS
    if credentials is None:
        raise HTTPException(status_code=401, detail={"code": "AUTH_REQUIRED", "message": "Authentication required."})
    return verify_token(credentials.credentials)
