"""Application configuration, loaded from environment variables (prefix MEDORA_)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BACKEND_DIR / ".env",
        env_prefix="MEDORA_",
        extra="ignore",
    )

    app_name: str = "Medora AI V2 Backend"
    app_version: str = "0.1.0"
    environment: str = "development"
    api_prefix: str = "/api/v1"

    database_url: str = f"sqlite:///{(BACKEND_DIR / 'medora.db').as_posix()}"
    upload_dir: Path = BACKEND_DIR / "uploads"
    report_dir: Path = BACKEND_DIR / "reports"
    rag_data_dir: Path = BACKEND_DIR / "rag_data"
    models_dir: Path = BACKEND_DIR / "models"

    max_upload_bytes: int = 10 * 1024 * 1024
    allowed_image_formats: str = "JPEG,PNG"

    auth_enabled: bool = False

    yolo_weights_path: Path | None = None
    yolo_confidence: float = 0.25

    quality_min_side_px: int = 224
    quality_min_blur_variance: float = 50.0
    quality_min_brightness: float = 40.0
    quality_max_brightness: float = 220.0
    quality_min_contrast: float = 20.0
    quality_max_occlusion_ratio: float = 0.5

    # Risk thresholds apply to the model's severity_hint in [0, 1].
    # Configurable placeholders. NOT clinically validated.
    risk_blue_threshold: float = 0.25
    risk_amber_threshold: float = 0.5
    risk_red_threshold: float = 0.8
    low_confidence_threshold: float = 0.6

    @property
    def allowed_formats(self) -> set[str]:
        return {f.strip().upper() for f in self.allowed_image_formats.split(",") if f.strip()}


@lru_cache
def get_settings() -> Settings:
    return Settings()
