"""Logging setup. Never log secrets, file contents, or raw patient data."""

from __future__ import annotations

import logging

from app.core.config import get_settings


def configure_logging() -> None:
    level = logging.DEBUG if get_settings().environment == "development" else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
