"""FastAPI application factory.

No CORS middleware is configured on purpose: the frontend is connected in a later phase.
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api import auth, health, history, llm, reports, results, screening
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.database.database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    settings = get_settings()
    for directory in (settings.upload_dir, settings.report_dir, settings.rag_data_dir / "parquet"):
        directory.mkdir(parents=True, exist_ok=True)
    init_db()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Medora AI V2 backend. Screening is informational and is not a diagnosis.",
        lifespan=lifespan,
    )
    for module in (health, auth, screening, results, reports, history, llm):
        app.include_router(module.router, prefix=settings.api_prefix)
    return app


app = create_app()
