"""LLM endpoint. Returns 501 until a provider is implemented. Never returns a fake answer."""

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from app.llm.adapter import LLMAdapter, get_llm_adapter
from app.llm.interface import LLMNotImplementedError
from app.llm.schemas import LLMRequest, LLMResponse

router = APIRouter(prefix="/llm", tags=["llm"])


@router.post(
    "/generate",
    response_model=LLMResponse,
    responses={501: {"description": "NOT_IMPLEMENTED: no LLM provider is connected"}},
)
def generate(request: LLMRequest, adapter: LLMAdapter = Depends(get_llm_adapter)):
    try:
        return adapter.generate(request)
    except LLMNotImplementedError as exc:
        return JSONResponse(status_code=501, content={"error": "NOT_IMPLEMENTED", "message": str(exc)})
