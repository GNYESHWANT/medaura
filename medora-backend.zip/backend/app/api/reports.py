import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import Actor, get_current_actor
from app.database.database import get_db
from app.database.repository import ScreeningRepository
from app.schemas.report import ReportOut

router = APIRouter(prefix="/screenings", tags=["reports"])


@router.get(
    "/{screening_id}/report",
    response_model=ReportOut,
    responses={404: {"description": "No report for this screening"}},
)
def get_report(
    screening_id: str,
    db: Session = Depends(get_db),
    actor: Actor = Depends(get_current_actor),
) -> ReportOut:
    repo = ScreeningRepository(db)
    report_row = repo.get_report(screening_id)
    if report_row is None:
        raise HTTPException(404, detail={"code": "NOT_FOUND", "message": "Report not found."})

    # Only read files inside the configured report directory.
    report_dir = get_settings().report_dir.resolve()
    path = Path(report_row.file_path).resolve()
    if report_dir not in path.parents:
        raise HTTPException(500, detail={"code": "REPORT_PATH_INVALID", "message": "Report unavailable."})
    return ReportOut(**json.loads(path.read_text(encoding="utf-8")))
