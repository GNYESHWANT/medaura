import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.security import Actor, get_current_actor
from app.database.database import get_db
from app.database.repository import ScreeningRepository
from app.schemas.result import ScreeningResult

router = APIRouter(prefix="/screenings", tags=["results"])


@router.get(
    "/{screening_id}",
    response_model=ScreeningResult,
    responses={404: {"description": "Unknown screening id"}},
)
def get_screening_result(
    screening_id: str,
    db: Session = Depends(get_db),
    actor: Actor = Depends(get_current_actor),
) -> ScreeningResult:
    screening = ScreeningRepository(db).get_screening(screening_id)
    if screening is None:
        raise HTTPException(404, detail={"code": "NOT_FOUND", "message": "Screening not found."})
    if screening.result_json is None:
        return ScreeningResult(screening_id=screening.id, body_region=screening.body_region, status=screening.status)
    return ScreeningResult(**json.loads(screening.result_json))
