"""POST /screenings: accepts a region and an image, runs the pipeline, returns the id and status.

Not connected to any frontend. Test with Swagger, curl or Postman.
"""

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.core.security import Actor, get_current_actor
from app.database.database import get_db
from app.schemas.screening import ScreeningCreated
from app.services.image_service import ValidationFailure
from app.services.screening_service import ScreeningPipelineError, ScreeningService
from app.vision.router import UnsupportedRegion

router = APIRouter(prefix="/screenings", tags=["screening"])


@router.post(
    "",
    status_code=201,
    response_model=ScreeningCreated,
    responses={
        413: {"description": "File too large"},
        415: {"description": "Unsupported or mismatched media type"},
        422: {"description": "Invalid region, empty or undecodable image"},
        500: {"description": "Pipeline error; the screening record is marked failed"},
    },
)
def create_screening(
    region: str = Form(..., description="eye | skin | nails | mouth"),
    image: UploadFile = File(..., description="JPEG or PNG"),
    symptoms: str = Form("", max_length=500, description="Optional comma-separated symptom codes"),
    db: Session = Depends(get_db),
    actor: Actor = Depends(get_current_actor),
) -> ScreeningCreated:
    service = ScreeningService(db)
    try:
        screening = service.run(
            region_raw=region,
            upload=image,
            symptoms_raw=symptoms,
            actor_id=actor.id,
            authenticated=actor.authenticated,
        )
    except UnsupportedRegion as exc:
        raise HTTPException(422, detail={"code": "UNSUPPORTED_REGION", "message": str(exc)}) from exc
    except ValidationFailure as exc:
        raise HTTPException(exc.http_status, detail={"code": exc.code, "message": exc.message}) from exc
    except ScreeningPipelineError as exc:
        raise HTTPException(500, detail={"code": "PIPELINE_ERROR", "message": "Screening failed."}) from exc
    return ScreeningCreated(screening_id=screening.id, status=screening.status)
