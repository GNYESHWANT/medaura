"""Authentication surface. Architecture-ready; no provider is implemented yet."""

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.core.security import Actor, get_current_actor

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get("/status")
def auth_status(actor: Actor = Depends(get_current_actor)) -> dict:
    settings = get_settings()
    return {
        "auth_enabled": settings.auth_enabled,
        "mode": "bearer-required" if settings.auth_enabled else "anonymous",
        "actor": actor.id,
    }


@router.post("/login")
def login() -> JSONResponse:
    return JSONResponse(
        status_code=501,
        content={"code": "AUTH_NOT_IMPLEMENTED", "message": "Login is not implemented in this build."},
    )
