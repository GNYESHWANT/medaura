from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.security import Actor, get_current_actor
from app.database.database import get_db
from app.services.history_service import list_history

router = APIRouter(prefix="/history", tags=["history"])


@router.get("")
def history(
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    actor: Actor = Depends(get_current_actor),
) -> dict:
    items = list_history(db, limit=limit, offset=offset)
    return {"items": items, "limit": limit, "offset": offset}
