"""Risk/severity engine: severity banding, red flags, triage and specialist routing."""
