"""Triage: combines quality, model output, red flags and evidence into one assessment.

Rules, in order:
1. Red flags reported by the user force RED regardless of image or model.
2. Failed image quality => RETAKE_REQUIRED (no risk level).
3. No usable model output => MODEL_NOT_CONFIGURED (no risk level).
4. Otherwise the level comes from severity_hint banding only.

model_confidence is reported as a reason code when low, but never changes the level.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

from app.core.config import Settings, get_settings
from app.models.base import STATUS_OK, ModelPrediction
from app.risk.severity import SeverityThresholds, severity_level

THRESHOLDS_VERSION = "config-placeholder-v1 (not clinically validated)"

URGENCY_BY_LEVEL = {
    "RED": "seek_prompt_professional_review",
    "AMBER": "seek_professional_review_soon",
    "BLUE": "monitor_and_recheck",
    "GREEN": "routine_monitoring",
}


@dataclass
class RiskAssessment:
    risk_level: str | None
    screening_status: str  # COMPLETED | RETAKE_REQUIRED | MODEL_NOT_CONFIGURED
    urgency: str
    reason_codes: list[str] = field(default_factory=list)
    thresholds_version: str = THRESHOLDS_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


def assess(
    *,
    quality_passed: bool,
    prediction: ModelPrediction | None,
    red_flags: list[str],
    evidence_count: int,
    settings: Settings | None = None,
) -> RiskAssessment:
    s = settings or get_settings()
    thresholds = SeverityThresholds.from_settings(s)
    reasons: list[str] = [f"RED_FLAG:{code}" for code in red_flags]

    level: str | None = None
    status = "COMPLETED"
    urgency = "no_assessment_available"

    if not quality_passed:
        status = "RETAKE_REQUIRED"
        urgency = "retake_image"
        reasons.append("IMAGE_QUALITY_FAILED")
    elif prediction is None or prediction.status != STATUS_OK:
        status = "MODEL_NOT_CONFIGURED"
        urgency = "no_image_assessment_available"
        reasons.append("MODEL_NOT_CONFIGURED")
    elif prediction.severity_hint is None:
        urgency = "no_severity_signal_available"
        reasons.append("NO_SEVERITY_SIGNAL")
    else:
        level = severity_level(prediction.severity_hint, thresholds)
        urgency = URGENCY_BY_LEVEL[level]
        if prediction.model_confidence is not None and prediction.model_confidence < s.low_confidence_threshold:
            reasons.append("LOW_MODEL_CONFIDENCE")
        if evidence_count == 0:
            reasons.append("NO_RETRIEVED_EVIDENCE")

    if red_flags:
        level = "RED"
        urgency = URGENCY_BY_LEVEL["RED"]

    return RiskAssessment(risk_level=level, screening_status=status, urgency=urgency, reason_codes=reasons)
