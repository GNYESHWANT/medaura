"""Red-flag registry. Codes come from a curated JSON file, never from an LLM."""

from __future__ import annotations

import json
from pathlib import Path

DATA_PATH = Path(__file__).parent / "data" / "red_flags.json"


class RedFlagRegistry:
    def __init__(self, path: Path = DATA_PATH) -> None:
        self._data = json.loads(path.read_text(encoding="utf-8"))
        self._codes: dict[str, set[str]] = {
            region: {entry["code"] for entry in entries}
            for region, entries in self._data["regions"].items()
        }

    def known_codes(self, region: str) -> set[str]:
        return set(self._codes.get(region, set()))

    def check(self, region: str, reported: set[str]) -> list[str]:
        """Return only reported codes that are recognised red flags for this region."""
        return sorted(reported & self.known_codes(region))
