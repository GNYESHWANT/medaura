"""Severity banding from a model's severity_hint.

Thresholds are configurable placeholders. They are NOT clinically validated.
Model confidence is deliberately NOT an input here: a 0.90-confidence label
does not, on its own, imply severe disease.
"""

from __future__ import annotations

from dataclasses import dataclass

from app.core.config import Settings


@dataclass(frozen=True)
class SeverityThresholds:
    blue: float
    amber: float
    red: float

    def __post_init__(self) -> None:
        if not 0.0 <= self.blue <= self.amber <= self.red <= 1.0:
            raise ValueError("Thresholds must satisfy 0 <= blue <= amber <= red <= 1")

    @classmethod
    def from_settings(cls, settings: Settings) -> SeverityThresholds:
        return cls(settings.risk_blue_threshold, settings.risk_amber_threshold, settings.risk_red_threshold)


def severity_level(score: float, thresholds: SeverityThresholds) -> str:
    if not 0.0 <= score <= 1.0:
        raise ValueError("severity_hint must be within [0, 1]")
    if score >= thresholds.red:
        return "RED"
    if score >= thresholds.amber:
        return "AMBER"
    if score >= thresholds.blue:
        return "BLUE"
    return "GREEN"
