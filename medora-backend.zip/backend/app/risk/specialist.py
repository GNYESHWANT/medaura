"""Curated specialist routing. Mappings live in data/specialist_map.json.

An LLM must never invent or alter these mappings.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

DATA_PATH = Path(__file__).parent / "data" / "specialist_map.json"


@dataclass
class SpecialistRecommendation:
    specialty: str
    professional: str
    mapping_key: str
    source: str  # region_default | finding_override | fallback
    mapping_version: str

    def to_dict(self) -> dict:
        return asdict(self)


class SpecialistRouter:
    def __init__(self, path: Path = DATA_PATH) -> None:
        self._data = json.loads(path.read_text(encoding="utf-8"))
        for region, entry in self._data["regions"].items():
            self._validate_entry(region, entry)
        self._validate_entry("fallback", self._data["fallback"])

    @staticmethod
    def _validate_entry(key: str, entry: dict) -> None:
        if not entry.get("specialty") or not entry.get("professional"):
            raise ValueError(f"Specialist mapping '{key}' must define specialty and professional")

    @property
    def version(self) -> str:
        return self._data["version"]

    def route(self, region: str, finding: str | None = None) -> SpecialistRecommendation:
        if finding:
            key = f"{region}:{finding}"
            override = self._data["finding_overrides"].get(key)
            if override:
                return SpecialistRecommendation(override["specialty"], override["professional"], key,
                                                "finding_override", self.version)
        if region in self._data["regions"]:
            entry = self._data["regions"][region]
            return SpecialistRecommendation(entry["specialty"], entry["professional"], region,
                                            "region_default", self.version)
        fallback = self._data["fallback"]
        return SpecialistRecommendation(fallback["specialty"], fallback["professional"], "fallback",
                                        "fallback", self.version)
