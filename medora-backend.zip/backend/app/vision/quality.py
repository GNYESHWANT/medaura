"""Technical image-quality checks.

These metrics describe the PHOTOGRAPH only. They do not establish clinical
validity and must never be presented as a health assessment.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

import cv2
import numpy as np

from app.core.config import Settings, get_settings

QUALITY_DISCLAIMER = (
    "Technical image-quality checks only. These metrics describe the photograph, "
    "not the health of the body part, and do not establish clinical validity."
)


@dataclass
class QualityMetric:
    name: str
    value: float
    threshold: str
    passed: bool


@dataclass
class QualityReport:
    quality_score: float  # fraction of checks passed, 0..1
    passed: bool
    metrics: list[QualityMetric]
    reasons: list[str] = field(default_factory=list)
    disclaimer: str = QUALITY_DISCLAIMER

    def to_dict(self) -> dict:
        return asdict(self)


class ImageQualityService:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    def assess(self, image: np.ndarray) -> QualityReport:
        if image is None or image.size == 0:
            raise ValueError("Empty image")

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image
        height, width = gray.shape[:2]
        s = self.settings

        min_side = float(min(height, width))
        sharpness = float(cv2.Laplacian(gray, cv2.CV_64F).var())  # "blur" / focus signal
        brightness = float(gray.mean())
        contrast = float(gray.std())
        occlusion = float(np.mean((gray < 10) | (gray > 245)))  # heuristic: clipped/blocked pixels

        metrics = [
            QualityMetric(
                "resolution_min_side_px", min_side, f">= {s.quality_min_side_px}",
                min_side >= s.quality_min_side_px,
            ),
            QualityMetric(
                "blur_laplacian_variance", sharpness, f">= {s.quality_min_blur_variance}",
                sharpness >= s.quality_min_blur_variance,
            ),
            QualityMetric(
                "brightness_mean", brightness,
                f"{s.quality_min_brightness} to {s.quality_max_brightness}",
                s.quality_min_brightness <= brightness <= s.quality_max_brightness,
            ),
            QualityMetric(
                "contrast_std", contrast, f">= {s.quality_min_contrast}",
                contrast >= s.quality_min_contrast,
            ),
            QualityMetric(
                "occlusion_ratio", occlusion, f"<= {s.quality_max_occlusion_ratio}",
                occlusion <= s.quality_max_occlusion_ratio,
            ),
        ]

        passed_count = sum(1 for m in metrics if m.passed)
        reasons = [
            f"{m.name} failed (value={m.value:.2f}, required {m.threshold})"
            for m in metrics
            if not m.passed
        ]
        return QualityReport(
            quality_score=round(passed_count / len(metrics), 3),
            passed=passed_count == len(metrics),
            metrics=metrics,
            reasons=reasons,
        )
