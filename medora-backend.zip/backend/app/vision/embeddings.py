"""Image-embedding interface. No embedder is configured in this build."""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from app.models.base import ModelNotConfigured


class ImageEmbedder(ABC):
    @abstractmethod
    def embed(self, image: np.ndarray) -> np.ndarray:
        """Return a 1-D embedding vector for the image."""


class NotConfiguredImageEmbedder(ImageEmbedder):
    def embed(self, image: np.ndarray) -> np.ndarray:
        raise ModelNotConfigured("Image embedder is not configured")


def get_image_embedder() -> ImageEmbedder:
    return NotConfiguredImageEmbedder()
