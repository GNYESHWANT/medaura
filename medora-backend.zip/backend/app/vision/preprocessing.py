"""Image decoding, ROI cropping and model-input preparation."""

from __future__ import annotations

import cv2
import numpy as np


def decode_image(data: bytes) -> np.ndarray:
    """Decode bytes to a BGR ndarray. Raises ValueError if the bytes are not a decodable image."""
    buffer = np.frombuffer(data, dtype=np.uint8)
    image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("Image could not be decoded")
    return image


def clamp_box(box: tuple[int, int, int, int], width: int, height: int) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    x1, x2 = max(0, min(x1, width)), max(0, min(x2, width))
    y1, y2 = max(0, min(y1, height)), max(0, min(y2, height))
    return x1, y1, x2, y2


def crop_roi(image: np.ndarray, box: tuple[int, int, int, int]) -> np.ndarray:
    """Crop a region of interest. Falls back to the full image for degenerate boxes."""
    height, width = image.shape[:2]
    x1, y1, x2, y2 = clamp_box(box, width, height)
    if x2 <= x1 or y2 <= y1:
        return image
    return image[y1:y2, x1:x2].copy()


def to_model_input(image: np.ndarray, size: int) -> np.ndarray:
    return cv2.resize(image, (size, size), interpolation=cv2.INTER_AREA)
