"""Body-region routing: validates the requested region and selects its model."""

from __future__ import annotations

from pathlib import Path

from app.models.base import RegionModel
from app.models.eye import EyeModel
from app.models.mouth import MouthModel
from app.models.nails import NailModel
from app.models.skin import SkinModel

SUPPORTED_REGIONS: tuple[str, ...] = ("eye", "skin", "nails", "mouth")

_MODEL_CLASSES: dict[str, type[RegionModel]] = {
    "eye": EyeModel,
    "skin": SkinModel,
    "nails": NailModel,
    "mouth": MouthModel,
}


class UnsupportedRegion(ValueError):
    pass


def normalize_region(value: str) -> str:
    region = (value or "").strip().lower()
    if region not in SUPPORTED_REGIONS:
        raise UnsupportedRegion(f"Unsupported region '{value}'. Expected one of: {', '.join(SUPPORTED_REGIONS)}")
    return region


def get_region_model(region: str, models_dir: Path | None = None) -> RegionModel:
    return _MODEL_CLASSES[normalize_region(region)](models_dir)


def build_region_models(models_dir: Path | None = None) -> dict[str, RegionModel]:
    return {region: get_region_model(region, models_dir) for region in SUPPORTED_REGIONS}
