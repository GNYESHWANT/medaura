"""Vision pipeline: quality, YOLO localisation, region routing, preprocessing, embeddings."""
