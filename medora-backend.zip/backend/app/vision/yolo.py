"""YOLO abstraction for ANATOMICAL / VISUAL LOCALISATION only.

YOLO is not the disease classifier. It finds the region of interest that the
region-specific model then analyses. Ultralytics is imported lazily and is not
a default dependency.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from app.models.base import MODEL_NOT_CONFIGURED, ModelNotConfigured
from app.vision.preprocessing import crop_roi


@dataclass
class Detection:
    label: str
    confidence: float
    box: tuple[int, int, int, int]  # x1, y1, x2, y2 in pixels


@dataclass
class DetectionResult:
    status: str
    detections: list[Detection]
    roi: np.ndarray | None
    message: str | None = None

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "message": self.message,
            "detections": [asdict(d) for d in self.detections],
            "roi_extracted": self.roi is not None,
        }


class YoloDetector:
    def __init__(self, weights_path: Path | None, confidence: float = 0.25) -> None:
        self.weights_path = weights_path
        self.confidence = confidence
        self._model = None

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def load(self) -> None:
        if self.weights_path is None or not Path(self.weights_path).exists():
            raise ModelNotConfigured("No YOLO weights configured (MEDORA_YOLO_WEIGHTS_PATH)")
        try:
            from ultralytics import YOLO  # lazy import: optional dependency
        except ImportError as exc:
            raise ModelNotConfigured("ultralytics is not installed") from exc
        self._model = YOLO(str(self.weights_path))

    def detect(self, image: np.ndarray) -> DetectionResult:
        if not self.is_loaded:
            try:
                self.load()
            except ModelNotConfigured as exc:
                return DetectionResult(status=MODEL_NOT_CONFIGURED, detections=[], roi=None, message=str(exc))

        detections: list[Detection] = []
        for result in self._model.predict(image, conf=self.confidence, verbose=False):
            names = result.names
            for box in result.boxes:
                x1, y1, x2, y2 = (int(v) for v in box.xyxy[0].tolist())
                detections.append(
                    Detection(
                        label=str(names[int(box.cls[0])]),
                        confidence=float(box.conf[0]),
                        box=(x1, y1, x2, y2),
                    )
                )

        if not detections:
            return DetectionResult(status="NO_DETECTION", detections=[], roi=None, message="No region detected")

        best = max(detections, key=lambda d: d.confidence)
        return DetectionResult(
            status="OK",
            detections=detections,
            roi=crop_roi(image, best.box),
        )
