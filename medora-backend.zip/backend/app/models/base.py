"""Common interface for region-specific ML models.

Rule: a model that has no trained weights, or no inference backend, returns
MODEL_NOT_CONFIGURED. It never fabricates a prediction.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from app.core.config import get_settings

MODEL_NOT_CONFIGURED = "MODEL_NOT_CONFIGURED"
STATUS_OK = "OK"


class ModelNotConfigured(RuntimeError):
    """Raised when trained weights or an inference backend are unavailable."""


@dataclass
class ModelPrediction:
    status: str
    region: str
    label: str | None = None
    model_confidence: float | None = None  # how sure the model is about its label
    severity_hint: float | None = None  # ordinal severity signal in [0, 1]; kept SEPARATE from confidence
    model_version: str | None = None
    raw: dict | None = None
    message: str | None = None


class RegionModel:
    region: str = ""
    weights_subdir: str = ""

    def __init__(self, models_dir: Path | None = None) -> None:
        self.models_dir = models_dir or get_settings().models_dir
        self._loaded = False

    @property
    def weights_path(self) -> Path:
        return self.models_dir / self.weights_subdir / "model.pt"

    def load(self) -> None:
        if not self.weights_path.exists():
            raise ModelNotConfigured(f"No weights for '{self.region}' at {self.weights_path}")
        self._backend_load(self.weights_path)
        self._loaded = True

    def _backend_load(self, path: Path) -> None:
        # Real inference backends override this. The default refuses rather than pretending.
        raise ModelNotConfigured(f"No inference backend implemented for '{self.region}' yet")

    def _infer(self, image: np.ndarray) -> ModelPrediction:
        raise NotImplementedError

    def predict(self, image: np.ndarray) -> ModelPrediction:
        if not self._loaded:
            try:
                self.load()
            except ModelNotConfigured as exc:
                return ModelPrediction(status=MODEL_NOT_CONFIGURED, region=self.region, message=str(exc))
        return self.validate_output(self._infer(image))

    def validate_output(self, prediction: ModelPrediction) -> ModelPrediction:
        if prediction.status == STATUS_OK:
            if not prediction.label:
                raise ValueError("OK prediction must include a label")
            for name in ("model_confidence", "severity_hint"):
                value = getattr(prediction, name)
                if value is not None and not 0.0 <= value <= 1.0:
                    raise ValueError(f"{name} must be within [0, 1]")
        return prediction
