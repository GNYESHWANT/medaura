"""Mouth model. Weights expected at models/mouth/model.pt. Not configured yet."""

from app.models.base import RegionModel


class MouthModel(RegionModel):
    region = "mouth"
    weights_subdir = "mouth"
