"""Nail model. Weights expected at models/nails/model.pt. Not configured yet."""

from app.models.base import RegionModel


class NailModel(RegionModel):
    region = "nails"
    weights_subdir = "nails"
