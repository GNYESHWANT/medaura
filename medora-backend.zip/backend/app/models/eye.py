"""Eye model. Weights expected at models/eye/model.pt. Not configured yet."""

from app.models.base import RegionModel


class EyeModel(RegionModel):
    region = "eye"
    weights_subdir = "eye"
