"""Skin model. Weights expected at models/skin/model.pt. Not configured yet."""

from app.models.base import RegionModel


class SkinModel(RegionModel):
    region = "skin"
    weights_subdir = "skin"
