"""Region-specific model interfaces. See base.py for the shared contract."""
