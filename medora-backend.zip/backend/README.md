# Medora AI V2: Backend

FastAPI backend foundation. It is independently testable and **not connected to any frontend**.

Status summary:
- Screening pipeline, persistence, reports, history, risk engine, specialist routing: implemented.
- Region ML models, YOLO detector, RAG retrieval, image embeddings: **interfaces only**. They return
  `MODEL_NOT_CONFIGURED` / `EMBEDDER_NOT_CONFIGURED` until real artifacts are provided.
- LLM: **not implemented**. `POST /api/v1/llm/generate` returns `501`.
- Authentication: architecture-ready. Disabled by default, anonymous actor.

## Setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # edit as needed; never commit .env
```

## Database initialisation

Tables are created automatically at startup (`init_db()` in the app lifespan). To initialise
explicitly:

```bash
python -c "from app.database.database import init_db; init_db(); print('ok')"
```

For PostgreSQL, set `MEDORA_DATABASE_URL` (e.g. `postgresql+psycopg://user:pass@host/medora`),
install a driver, and replace `create_all` with migrations before production use.

## RAG tables

Create empty, schema-valid Parquet tables (idempotent):

```bash
python -m app.rag.ingest
```

Tables live in `rag_data/parquet/`. Curated rows are written through `app.rag.ingest.ingest_rows`.

## Run the development server

```bash
uvicorn app.main:app --reload
```

- Swagger UI: http://127.0.0.1:8000/docs
- OpenAPI JSON: http://127.0.0.1:8000/openapi.json
- Health: `curl http://127.0.0.1:8000/api/v1/health`

## Example: submit a screening

```bash
curl -X POST http://127.0.0.1:8000/api/v1/screenings \
  -F region=eye \
  -F "image=@./sample.png;type=image/png" \
  -F "symptoms="
```

Then fetch the result with `GET /api/v1/screenings/{screening_id}`. Full contracts are in
`API_CONTRACT.md`.

## Tests

```bash
pytest
```

The suite uses an isolated temporary database and directories (set in `tests/conftest.py`).
It requires no models, no network, and no API keys.

## Layout

```
app/
  api/        HTTP routers (health, auth, screening, results, reports, history, llm)
  core/       config (MEDORA_* env), logging, security (filenames, auth-ready actor)
  schemas/    Pydantic response models
  services/   screening orchestration, image handling, reports, history
  vision/     quality, YOLO localisation, region router, preprocessing, embeddings
  models/     region model interfaces (eye, skin, nails, mouth) with MODEL_NOT_CONFIGURED
  rag/        Parquet schemas and ingestion; embed/retrieve/rerank interfaces
  risk/       severity banding, red flags, triage, curated specialist routing (JSON data)
  llm/        provider interface, adapter (empty), schemas, README
  database/   SQLAlchemy models, engine/session, repository
tests/        pytest suite
rag_data/     Parquet knowledge store and staging folders
models/       weights per region (yolo/, eye/, skin/, nails/, mouth/); empty for now
uploads/      stored images (server-generated names)
reports/      structured JSON reports
```

## Design rules

1. **Confidence is not severity.** `model_confidence` and `severity_hint` are separate. Risk
   bands come from `severity_hint` only.
2. **No fabricated predictions.** Missing weights or backends produce `MODEL_NOT_CONFIGURED`.
3. **Thresholds are placeholders.** All risk thresholds are configurable and marked not clinically
   validated. Clinical sign-off is required before any real use.
4. **Curated, not generated.** Specialist mappings and red-flag codes come from JSON files under
   `app/risk/data/`. An LLM must not change them.
5. **Quality is technical only.** Image-quality metrics describe the photo, not health.
6. **No LLM, no API keys, no CORS.** The LLM is an empty contract. CORS is added with the frontend.
7. **Parquet is canonical storage, not a vector database.** Retrieval sits behind interfaces.

## Security notes

- Upload type is checked by declared content type **and** by decoding the bytes (Pillow).
- Size is capped by `MEDORA_MAX_UPLOAD_BYTES` (default 10 MB) and enforced while reading.
- Stored filenames are server-generated UUIDs. Client filenames are sanitised and only kept as
  metadata.
- Report reads are restricted to the configured report directory.
- Secrets belong in environment variables or a secrets manager, never in the repository.
- Audit rows are written for uploads rejected, screenings created, completed and failed.

## Medical disclaimer

This software produces informational screening output. It is not a diagnosis and must not be
used as a substitute for examination by a qualified health professional. It is not validated
for clinical use.
